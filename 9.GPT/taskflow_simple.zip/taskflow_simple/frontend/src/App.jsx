import { useEffect, useMemo, useState } from 'react';
import { api, setToken, getToken } from './api.js';
import './styles.css';

function Field({ label, value, onChange, type = 'text' }) {
  return (
    <label style={{ display: 'grid', gap: 6, width: '100%' }}>
      <span className="muted" style={{ fontSize: 13 }}>{label}</span>
      <input className="input" type={type} value={value} onChange={(e) => onChange(e.target.value)} />
    </label>
  );
}

function AuthCard({ onAuthed }) {
  const [mode, setMode] = useState('login'); // login | signup
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [msg, setMsg] = useState('');
  const [loading, setLoading] = useState(false);

  async function submit() {
    setMsg('');
    setLoading(true);
    try {
      if (mode === 'signup') {
        await api.signup({ email, password, name });
        setMsg('✅ 가입 완료! 이제 로그인 해주세요.');
        setMode('login');
      } else {
        const data = await api.login({ email, password });
        setToken(data.accessToken);
        onAuthed();
      }
    } catch (e) {
      setMsg(`❌ ${e.message}`);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="card" style={{ maxWidth: 420, margin: '80px auto' }}>
      <h2 style={{ marginTop: 0 }}>TaskFlow</h2>
      <p className="muted" style={{ marginTop: 0 }}>
        {mode === 'login' ? '로그인 후 워크스페이스/보드를 확인합니다.' : '간단 가입 후 바로 사용 가능합니다.'}
      </p>

      <div className="row" style={{ marginBottom: 12 }}>
        <button className={"btn " + (mode === 'login' ? 'primary' : '')} onClick={() => setMode('login')}>로그인</button>
        <button className={"btn " + (mode === 'signup' ? 'primary' : '')} onClick={() => setMode('signup')}>회원가입</button>
      </div>

      <div style={{ display: 'grid', gap: 10 }}>
        {mode === 'signup' && <Field label="이름" value={name} onChange={setName} />}
        <Field label="이메일" value={email} onChange={setEmail} />
        <Field label="비밀번호" value={password} onChange={setPassword} type="password" />
        <button className="btn primary" onClick={submit} disabled={loading}>
          {loading ? '처리중...' : (mode === 'login' ? '로그인' : '가입하기')}
        </button>
        {msg && <div className="muted" role="alert">{msg}</div>}
      </div>
    </div>
  );
}

function Board({ projectId, onBack }) {
  const [loading, setLoading] = useState(true);
  const [board, setBoard] = useState(null);
  const [err, setErr] = useState('');
  const [newTitleByCol, setNewTitleByCol] = useState({});

  async function load() {
    setLoading(true);
    setErr('');
    try {
      const data = await api.board(projectId);
      setBoard(data);
    } catch (e) {
      setErr(e.message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); }, [projectId]);

  async function addTask(columnId) {
    const title = (newTitleByCol[columnId] || '').trim();
    if (!title) return;
    await api.createTask(columnId, { title, description: '' });
    setNewTitleByCol((p) => ({ ...p, [columnId]: '' }));
    load();
  }

  async function move(taskId, fromColumnId, direction) {
    // very simple: move to prev/next column (by column order)
    const cols = board.columns;
    const idx = cols.findIndex(c => c.id === fromColumnId);
    const next = cols[idx + direction];
    if (!next) return;

    // put on top in new column
    await api.moveTask(taskId, { toColumnId: next.id, toOrder: 1 });
    load();
  }

  async function remove(taskId) {
    await api.deleteTask(taskId);
    load();
  }

  if (loading) return <div className="container"><div className="card">불러오는 중...</div></div>;
  if (err) return <div className="container"><div className="card">오류: {err}</div></div>;
  if (!board) return null;

  return (
    <div className="container">
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <h2 style={{ margin: 0 }}>Kanban Board</h2>
        <button className="btn" onClick={onBack}>← 프로젝트로</button>
      </div>
      <div className="hr" />
      <div className="grid3">
        {board.columns.map((col) => (
          <div className="card col" key={col.id}>
            <h3 style={{ marginTop: 0 }}>{col.name}</h3>

            <div className="row" style={{ marginBottom: 10 }}>
              <input
                className="input"
                placeholder="새 태스크 제목"
                value={newTitleByCol[col.id] || ''}
                onChange={(e) => setNewTitleByCol((p) => ({ ...p, [col.id]: e.target.value }))}
              />
              <button className="btn primary" onClick={() => addTask(col.id)}>추가</button>
            </div>

            <div style={{ display: 'grid', gap: 10 }}>
              {(board.tasksByColumn[col.id] || []).map((t) => (
                <div className="task" key={t.id}>
                  <h4>{t.title}</h4>
                  {t.description ? <p>{t.description}</p> : <p className="muted">설명 없음</p>}
                  <div className="row" style={{ marginTop: 8, justifyContent: 'space-between' }}>
                    <div className="row">
                      <button className="btn" onClick={() => move(t.id, col.id, -1)}>←</button>
                      <button className="btn" onClick={() => move(t.id, col.id, +1)}>→</button>
                    </div>
                    <button className="btn danger" onClick={() => remove(t.id)}>삭제</button>
                  </div>
                </div>
              ))}
              {(board.tasksByColumn[col.id] || []).length === 0 && (
                <div className="muted">태스크가 없습니다.</div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function App() {
  const [ready, setReady] = useState(false);
  const [authed, setAuthed] = useState(!!getToken());
  const [user, setUser] = useState(null);

  const [workspaces, setWorkspaces] = useState([]);
  const [projects, setProjects] = useState([]);
  const [selectedWs, setSelectedWs] = useState('');
  const [selectedProject, setSelectedProject] = useState('');

  const [newProjectName, setNewProjectName] = useState('');
  const [msg, setMsg] = useState('');

  async function bootstrap() {
    setMsg('');
    setReady(false);
    try {
      const me = await api.me();
      setUser(me);

      const ws = await api.workspaces();
      setWorkspaces(ws.items);
      const firstWs = ws.items[0]?.id || '';
      setSelectedWs(firstWs);

      if (firstWs) {
        const ps = await api.projects(firstWs);
        setProjects(ps.items);
      } else {
        setProjects([]);
      }
    } catch (e) {
      setMsg(e.message);
      setAuthed(false);
      setToken('');
    } finally {
      setReady(true);
    }
  }

  useEffect(() => {
    if (authed) bootstrap();
    else setReady(true);
  }, [authed]);

  useEffect(() => {
    if (!authed || !selectedWs) return;
    api.projects(selectedWs)
      .then((d) => setProjects(d.items))
      .catch(() => setProjects([]));
  }, [selectedWs, authed]);

  async function createProject() {
    const name = newProjectName.trim();
    if (!name) return;
    await api.createProject(selectedWs, { name, description: '' });
    setNewProjectName('');
    const ps = await api.projects(selectedWs);
    setProjects(ps.items);
  }

  function logout() {
    setToken('');
    setAuthed(false);
    setUser(null);
    setSelectedProject('');
  }

  const canShow = useMemo(() => authed && ready, [authed, ready]);

  if (!authed) return <AuthCard onAuthed={() => setAuthed(true)} />;

  if (!ready) return <div className="container"><div className="card">초기화 중...</div></div>;

  if (selectedProject) {
    return <Board projectId={selectedProject} onBack={() => setSelectedProject('')} />;
  }

  return (
    <div className="container">
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <div>
          <h2 style={{ margin: 0 }}>TaskFlow</h2>
          <div className="muted">안녕하세요, {user?.name} 님</div>
        </div>
        <button className="btn" onClick={logout}>로그아웃</button>
      </div>

      {msg && <div className="card" style={{ marginTop: 12 }}>오류: {msg}</div>}

      <div className="hr" />

      <div className="card">
        <h3 style={{ marginTop: 0 }}>워크스페이스</h3>
        <div className="row">
          <select className="input" value={selectedWs} onChange={(e) => setSelectedWs(e.target.value)}>
            {workspaces.map(w => <option key={w.id} value={w.id}>{w.name} ({w.role})</option>)}
          </select>
        </div>

        <div className="hr" />

        <h3 style={{ marginTop: 0 }}>프로젝트</h3>
        <div className="row" style={{ marginBottom: 12 }}>
          <input className="input" placeholder="새 프로젝트 이름" value={newProjectName} onChange={(e) => setNewProjectName(e.target.value)} />
          <button className="btn primary" onClick={createProject}>추가</button>
        </div>

        <div style={{ display: 'grid', gap: 10 }}>
          {projects.map((p) => (
            <div className="card" key={p.id} style={{ padding: 12 }}>
              <div className="row" style={{ justifyContent: 'space-between' }}>
                <div>
                  <div style={{ fontWeight: 700 }}>{p.name}</div>
                  <div className="muted" style={{ fontSize: 13 }}>{p.description || '설명 없음'}</div>
                </div>
                <button className="btn primary" onClick={() => setSelectedProject(p.id)}>보드 열기</button>
              </div>
            </div>
          ))}
          {projects.length === 0 && <div className="muted">프로젝트가 없습니다. 위에서 추가해보세요.</div>}
        </div>
      </div>
    </div>
  );
}

export default App;
